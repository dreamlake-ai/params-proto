
# API reference

Use `proto` to declare configuration, turn functions into command-line programs, and compose parameter overrides.

- [Decorator and configuration API](/api/proto): `@proto`, `@proto.cli`, `@proto.prefix`, and `proto.bind`.
- [Generated Python API](/reference): module signatures and docstrings extracted from this version's source.
- [Hyperparameter sweeps](/key_concepts/hyperparameter_sweeps): compose search spaces with `Sweep`.
- [Environment variables](/key_concepts/environment_variables): typed environment configuration with `EnvVar`.

## Earlier APIs

The generated API includes the `params_proto.v1` and `params_proto.v2` compatibility modules shipped with this release. For historical guides, select a previous version in the version menu.
