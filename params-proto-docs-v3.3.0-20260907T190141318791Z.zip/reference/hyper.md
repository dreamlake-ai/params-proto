
# params_proto.hyper

Hyperparameter sweep module for params-proto v3.

## Public imports

These symbols are available from this module. Their definitions are documented in the linked modules.

- [`ParameterIterator`](/reference/hyper/sweep#parameteriterator) — `params_proto.hyper.sweep.ParameterIterator`
- [`Sweep`](/reference/hyper/sweep#sweep) — `params_proto.hyper.sweep.Sweep`
