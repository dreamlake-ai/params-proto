
# params_proto.cli

CLI argument parsing and help generation for params-proto.

This module handles:
- Command-line argument parsing
- Help text generation
- ANSI colorization for terminal output

## Public imports

These symbols are available from this module. Their definitions are documented in the linked modules.

- [`parse_cli_args`](/reference/cli/cli_parse#parse_cli_args) — `params_proto.cli.cli_parse.parse_cli_args`
- [`colorize_help`](/reference/cli/ansi_help#colorize_help) — `params_proto.cli.ansi_help.colorize_help`
- [`get_terminal_width`](/reference/cli/ansi_help#get_terminal_width) — `params_proto.cli.ansi_help.get_terminal_width`
