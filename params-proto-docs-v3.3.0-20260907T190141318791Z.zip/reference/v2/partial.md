
# params_proto.v2.partial

## proto_partial

```python
def proto_partial(proto: ParamsProto, method=False)
```

Overrides the function with values from the Proto Object.

## Public imports

These symbols are available from this module. Their definitions are documented in the linked modules.

- [`ParamsProto`](/reference/v2/proto#paramsproto) — `params_proto.v2.proto.ParamsProto`
