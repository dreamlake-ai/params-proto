
# params_proto.cli.ansi_help

ANSI-formatted help text generation for terminal display.

Provides colorized, terminal-width-aware formatting of help text.
Keeps __help_str__ as plain text for testing, adds __ansi_str__ for display.

Terminal Detection Notes:
------------------------

Width Detection:
  - Uses shutil.get_terminal_size() which queries terminal dimensions
  - Checks COLUMNS env var first, then terminal ioctl
  - Width can change during a session (user resizes window)
  - For params-proto: No caching needed since help is printed once and exits
  - For long-running CLIs: Would need SIGWINCH handler or query-per-print
  - Current approach (query on each colorize_help() call) is correct and cheap

Color Detection:
  - Currently NOT implemented - colors always applied
  - Should check:
    * sys.stdout.isatty() - False for pipes/redirects
    * NO_COLOR env var - https://no-color.org/
    * TERM env var - 'dumb' or missing means no color support
  - TODO: Add should_use_color() function

Performance:
  - shutil.get_terminal_size() is fast (just reads terminal attributes)
  - No need to cache width since help is only printed once per execution
  - For high-frequency printing, would consider caching with SIGWINCH handler

## Colors

```python
class Colors
```

ANSI color codes for terminal formatting.

```python
RESET = '\x1b[0m'
```

```python
BOLD = '\x1b[1m'
```

```python
DIM = '\x1b[2m'
```

```python
RED = '\x1b[31m'
```

```python
GREEN = '\x1b[32m'
```

```python
YELLOW = '\x1b[33m'
```

```python
BLUE = '\x1b[34m'
```

```python
MAGENTA = '\x1b[35m'
```

```python
CYAN = '\x1b[36m'
```

```python
WHITE = '\x1b[37m'
```

```python
BRIGHT_BLACK = '\x1b[90m'
```

```python
BRIGHT_RED = '\x1b[91m'
```

```python
BRIGHT_GREEN = '\x1b[92m'
```

```python
BRIGHT_YELLOW = '\x1b[93m'
```

```python
BRIGHT_BLUE = '\x1b[94m'
```

```python
BRIGHT_MAGENTA = '\x1b[95m'
```

```python
BRIGHT_CYAN = '\x1b[96m'
```

## get_terminal_width

```python
def get_terminal_width(default: int=80, max_width: int=120) -> int
```

Get the current terminal width.

Args:
    default: Default width if terminal size cannot be detected
    max_width: Maximum width to use even if terminal is wider

Returns:
    Terminal width in characters

## strip_ansi

```python
def strip_ansi(text: str) -> str
```

Remove ANSI escape codes from text.

Args:
    text: Text potentially containing ANSI codes

Returns:
    Plain text with ANSI codes removed

## wrap_text_with_ansi

```python
def wrap_text_with_ansi(text: str, width: int, indent: str='') -> list
```

Wrap text while preserving ANSI codes.

Args:
    text: Text to wrap (may contain ANSI codes)
    width: Target width for wrapping
    indent: Indentation string for wrapped lines

Returns:
    List of wrapped lines

## colorize_help

```python
def colorize_help(help_str: str, width: Optional[int]=None) -> str
```

Add ANSI colors and line wrapping to help text.

Colorization:
- Type names (INT, STR, FLOAT, etc.) -&gt; bold bright blue ([1m[94m)
- (required) -&gt; bold red ([1m[31m)
- (default: value) -&gt; cyan parentheses with bold cyan value
  Example: [36m(default:[0m [1m[36m128[0m[36m)[0m
- Option names (--foo) -&gt; plain text (no formatting)

Args:
    help_str: Plain text help string
    width: Terminal width (auto-detected if None)

Returns:
    ANSI-formatted help text with proper line wrapping

## get_ansi_help

```python
def get_ansi_help(wrapper) -> str
```

Get ANSI-formatted help string from a proto wrapper.

Args:
    wrapper: ProtoWrapper instance with __help_str__

Returns:
    ANSI-formatted help text
