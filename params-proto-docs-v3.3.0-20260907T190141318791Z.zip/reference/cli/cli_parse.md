
# params_proto.cli.cli_parse

CLI argument parsing for params-proto v3.

Converts sys.argv into kwargs for proto-decorated functions.
Simple custom parser - no argparse dependency.

## parse_cli_args

```python
def parse_cli_args(wrapper) -> Dict[str, Any]
```

Parse CLI arguments for a ProtoWrapper.

Args:
    wrapper: ProtoWrapper instance

Returns:
    Dictionary of parsed arguments
