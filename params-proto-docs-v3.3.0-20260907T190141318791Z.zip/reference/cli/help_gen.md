
# params_proto.cli.help_gen

Help text generation for params-proto.

Generates comprehensive CLI help text from function signatures,
inline comments, and docstrings.
