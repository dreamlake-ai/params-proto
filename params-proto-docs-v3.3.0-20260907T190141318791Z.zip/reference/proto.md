
# params_proto.proto

params-proto v3 API

Core decorators and functionality for declarative parameter management.

## ProtoResult

```python
class ProtoResult
```

Result object that provides attribute access to function results.

## ProtoResult.__init__

```python
def __init__(self, data: dict)
```

## ProtoWrapper

```python
class ProtoWrapper
```

Wrapper for proto-decorated functions.

## ProtoWrapper.__init__

```python
def __init__(self, func: Callable, is_cli: bool=False, is_prefix: bool=False, prog: str=None)
```

## ptype

```python
class ptype(type)
```

Metaclass for proto-decorated classes that intercepts attribute access.

## proto

```python
def proto(cls_or_func: Callable=None, *, cli: bool=False, prefix: bool=False, prefix_name: str=None, prog: str=None)
```

Main proto decorator that converts a class or function into a proto config object.

Args:
    cls_or_func: The class or function to decorate
    cli: If True, this is a CLI entry point (generates help)
    prefix: If True, creates a singleton instance with prefix in CLI
    prefix_name: Custom prefix name (defaults to lowercase class/function name)
    prog: Optional program name override for help generation (useful for testing)

Returns:
    Decorated class/function with attribute setting and calling support

## cli_decorator

```python
def cli_decorator(cls_or_func)
```

Decorator for CLI entry points.

## prefix_decorator

```python
def prefix_decorator(cls_or_func=None, name: str=None)
```

Decorator for prefixed singleton configs.

Args:
    cls_or_func: The class or function to decorate (or prefix name if called with string)
    name: Optional custom prefix name (defaults to lowercase class/function name)

Examples:
    @proto.prefix
    class Config: ...

    @proto.prefix("custom")
    class Config: ...

## BindContext

```python
class BindContext
```

Context manager for parameter bindings that also works as a direct call.

## BindContext.__init__

```python
def __init__(self, prev_state, **kwargs)
```

## bind

```python
def bind(**kwargs)
```

Bind parameter overrides.

Can be used as context manager:
    with proto.bind(seed=42, **&#123;"train.lr": 0.01&#125;):
        result = main()

Or as direct call (sets global bindings):
    proto.bind(seed=42, **&#123;"train.lr": 0.01&#125;)
    result = main()

## parse

```python
def parse(func: Callable, **kwargs)
```

Parse overrides and call a function.

Args:
    func: The function to call
    **kwargs: Override values (can use dot notation)

Returns:
    Result of calling func with overrides applied

## cli

```python
def cli(obj: F, *, prog: str=None) -> F
```

Decorate a function/class as CLI entry point (preserves type).

## cli

```python
def cli(obj: None=None, *, prog: str=None) -> Callable[[F], F]
```

Return a decorator for CLI entry points (preserves type).

## cli

```python
def cli(obj: Any=None, *, prog: str=None)
```

Set up an object as a CLI entry point.

By default, subcommand attributes don't require prefix (--epochs works).
If the subcommand class is decorated with @proto.prefix, prefix is required
(--config.epochs).

Args:
    obj: The class, function, or Union type to setup as CLI.
         If None, returns a decorator.
    prog: Optional program name override for help generation (useful for testing)

Returns:
    The object with CLI capabilities, or a decorator if obj is None

## partial

```python
def partial(config_class: Type, method: bool=False)
```

Decorator that injects parameter defaults from a config class into a function.

This allows you to define a plain class with type-annotated attributes and their
defaults, then use those defaults to populate function parameters automatically.

Args:
    config_class: A class with type-annotated attributes serving as parameter defaults
    method: If True, wraps as a method (for class methods)

Example:
    class Config:
      lr: float = 0.01
      batch_size: int = 32

    @proto.partial(Config)
    def train() -&gt; None:
      print(f"Learning Rate: &#123;Config.lr&#125;")
      print(f"Batch Size: &#123;Config.batch_size&#125;")

    # Supports direct attribute modification:
    Config.lr = 0.001
    train()  # Uses updated lr value

    # Supports hyperparameter sweeps:
    for Config.lr in [0.01, 0.001, 0.0001]:
      train()

Returns:
    Decorated function with config values injected as defaults
