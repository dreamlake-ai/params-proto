
# params_proto.hyper.sweep

v3 hyperparameter sweep implementation.

## ParameterIterator

```python
class ParameterIterator
```

Lazy iterator over parameter configurations.

Supports operations like product (*), override (%), and power (**).

## ParameterIterator.__init__

```python
def __init__(self, iterator, protos=None)
```

Initialize parameter iterator.

Args:
    iterator: Generator or iterable of config dicts
    protos: Optional dict of proto objects for context

## ParameterIterator.list

```python
def list(self)
```

Materialize all configs into a list.

## ParameterIterator.to_list

```python
def to_list(self)
```

Materialize all configs into a list (alias for .list).

## ParameterIterator.save

```python
def save(self, filename='sweep.jsonl', overwrite=True, verbose=True)
```

Save parameter configurations to JSONL file.

Args:
    filename: Path to output file (str or PathLike)
    overwrite: If True, overwrite existing file; if False, append
    verbose: If True, print save confirmation

Example:
    configs = piter @ &#123;"lr": [0.001, 0.01]&#125; * &#123;"batch_size": [32, 64]&#125;
    configs.save("experiment.jsonl")

## ParameterIterator.load

```python
def load(filename='sweep.jsonl')
```

Load parameter configurations from JSONL file.

Args:
    filename: Path to input file (str or PathLike)

Returns:
    ParameterIterator with loaded configurations

Example:
    configs = ParameterIterator.load("experiment.jsonl")
    for config in configs:
        run_experiment(**config)

## PiterFactory

```python
class PiterFactory
```

Factory for creating parameter iterators.

Supports both function-call syntax and @ operator syntax:
    piter(&#123;"lr": [0.001, 0.01]&#125;)      # function call
    piter @ &#123;"lr": [0.001, 0.01]&#125;     # @ operator

The @ operator enables clean chaining:
    piter @ &#123;"lr": [0.001, 0.01]&#125; * piter @ &#123;"batch_size": [32, 64]&#125;

## dot_join

```python
def dot_join(*keys)
```

Remove Nones from the keys, but not empty strings.

## key_items

```python
def key_items(d, prefix=None)
```

Takes in tuples of [key, value], or [None, [[key, value], ...]].
Yields items with optional prefix.

## flatten_items

```python
def flatten_items(row) -> Iterable[Item]
```

Recursively flatten nested items.

## SweepProxy

```python
class SweepProxy
```

Proxy that switches between normal delegation and sweep interception.

When not in sweep context: delegates all access directly to wrapped ptype class
When in sweep context: intercepts setattr to record sweep configurations

## SweepProxy.__init__

```python
def __init__(self, proto_obj)
```

Wrap a ptype class or ProtoWrapper.

Args:
    proto_obj: The actual proto class (ptype instance) or ProtoWrapper

## Sweep

```python
class Sweep
```

Hyperparameter sweep for v3 @proto decorated classes and functions.

Supports product, zip, chain, and set operations for combining parameter configurations.

## Sweep.__init__

```python
def __init__(self, *protos)
```

Initialize Sweep with proto objects.

Args:
    *protos: ProtoWrapper instances or metaclass-based proto classes

## Sweep.items

```python
def items(self)
```

Return enumerated sweep configurations.

## Sweep.list

```python
def list(self)
```

Convert sweep to list of configuration dicts.

## Sweep.to_list

```python
def to_list(self)
```

Convert sweep to list of configuration dicts (alias for .list).

## Sweep.dataframe

```python
def dataframe(self)
```

Convert sweep to pandas DataFrame.

## Sweep.noot

```python
def noot(self)
```

Return deep copy of root protos.

## Sweep.snack

```python
def snack(self)
```

Return deep copy of stack.

## Sweep.original

```python
def original(self)
```

Get original parameter values for each proto.

## Sweep.set_param

```python
def set_param(self, name, params, prefix=None)
```

Add parameter to current sweep stack.

## Sweep.product

```python
def product(self) -> ContextManager[None]
```

Context manager for Cartesian product of parameters.

## Sweep.zip

```python
def zip(self) -> ContextManager[None]
```

Context manager for element-wise zip of parameters.

## Sweep.set

```python
def set(self) -> ContextManager[None]
```

Context manager for setting fixed parameter values.

## Sweep.chain

```python
def chain(self) -> ContextManager[None]
```

Context manager for chaining multiple sweep configurations.

## Sweep.each

```python
def each(self, fn)
```

Register a function to be called for each configuration.

Useful for setting values that dynamically depend on other sweep values.

## Sweep.save

```python
def save(self, filename: str='sweep.jsonl', overwrite: bool=True, verbose: bool=True) -> None
```

Save sweep configurations to JSONL file.

## Sweep.save

```python
def save(self, filename: 'os.PathLike[str]', overwrite: bool=True, verbose: bool=True) -> None
```

Save sweep configurations to JSONL file.

## Sweep.save

```python
def save(self, filename='sweep.jsonl', overwrite=True, verbose=True)
```

Save sweep configurations to JSONL file.

Args:
    filename: Path to output file (str or PathLike)
    overwrite: If True, overwrite existing file; if False, append
    verbose: If True, print save confirmation

## Sweep.log

```python
def log(deps, filename)
```

Append single config to JSONL file.

## Sweep.read

```python
def read(filename)
```

Read JSONL file into list of dicts.

## Sweep.load

```python
def load(self, file: str, strict: bool=True, silent: bool=False) -> 'Sweep'
```

Load sweep configurations from JSONL file.

## Sweep.load

```python
def load(self, file: 'os.PathLike[str]', strict: bool=True, silent: bool=False) -> 'Sweep'
```

Load sweep configurations from JSONL file.

## Sweep.load

```python
def load(self, deps: List[Dict[str, Any]], strict: bool=True, silent: bool=False) -> 'Sweep'
```

Load sweep configurations from list of dicts.

## Sweep.load

```python
def load(self, df: 'pd.DataFrame', strict: bool=True, silent: bool=False) -> 'Sweep'
```

Load sweep configurations from pandas DataFrame.

## Sweep.load

```python
def load(self, file: Union[str, 'os.PathLike[str]', List[Dict[str, Any]], 'pd.DataFrame']='sweep.jsonl', strict: bool=True, silent: bool=False)
```

Load sweep configurations from JSONL file or list.

Args:
    file: Filename (str or PathLike), list of dicts, or pandas DataFrame
    strict: Raise error on missing attributes (default True)
    silent: Suppress warnings about missing attributes (default False)

Returns:
    self for chaining

## Public imports

These symbols are available from this module. Their definitions are documented in the linked modules.

- [`ProtoWrapper`](/reference/proto#protowrapper) — `params_proto.proto.ProtoWrapper`
- [`ptype`](/reference/proto#ptype) — `params_proto.proto.ptype`
