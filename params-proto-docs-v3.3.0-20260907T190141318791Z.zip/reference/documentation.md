
# params_proto.documentation

Documentation extraction utilities for params-proto.

Extracts parameter documentation from inline comments and docstrings,
combining them intelligently for comprehensive help text.
