
# params_proto.type_utils

Type utilities for params-proto.

Provides type conversion and type name extraction for CLI help generation.
